<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CoffeeshopController extends Controller
{
    public function Index()
    {
        return view('index');
    }
}
